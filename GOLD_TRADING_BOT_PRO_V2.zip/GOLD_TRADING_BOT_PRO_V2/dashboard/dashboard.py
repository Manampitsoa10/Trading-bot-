import json, time
from pathlib import Path
from flask import Flask, request, render_template_string, url_for
from config import UPLOAD_DIR, HISTORY_DIR, MAX_UPLOAD_MB
from image_analyzer.image_loader import load_image
from image_analyzer.chart_recognition import analyze_chart_image
from engine.signal_engine import build_strategy_notes

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

PAGE = r"""
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GOLD TRADING BOT PRO V2</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#080e1b;color:#edf2ff;font:15px Arial,sans-serif}
header{padding:22px 18px;background:linear-gradient(120deg,#101a30,#202d49);border-bottom:1px solid #34425e}
h1{margin:0;color:#f2c66d;font-size:24px}header p{color:#aab8d1;margin:8px 0 0}
main{max-width:1000px;margin:20px auto;padding:0 14px}.card{background:#131d32;border:1px solid #2c3a56;border-radius:16px;padding:17px;margin-bottom:16px}
h2{color:#f2c66d;font-size:19px;margin:0 0 13px}.muted{color:#aab8d1;line-height:1.5}
input[type=file]{width:100%;padding:13px;background:#0a1428;border:1px solid #35435f;border-radius:10px;color:#dce5f6}
button{background:#d9ad55;color:#111827;font-weight:bold;border:0;border-radius:9px;padding:13px 18px;margin-top:12px;width:100%;font-size:15px}
.pill{display:inline-block;border-radius:20px;padding:8px 12px;background:#283b5c;color:#ffdb8a;font-weight:bold}
.statgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:9px}
.stat{background:#0c162a;border:1px solid #293956;border-radius:10px;padding:12px}.stat b{display:block;font-size:19px;color:#f4d48f;margin-top:6px}
table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px 5px;border-bottom:1px solid #33415c;vertical-align:top}
img.preview{width:100%;height:auto;max-height:420px;object-fit:contain;background:#070b14;border-radius:10px}
.warning{color:#ffd48b}.error{color:#ff9999}details{margin-top:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#cbd7ee;font-size:12px}
footer{text-align:center;color:#8291ad;padding:22px;font-size:12px}
</style></head><body>
<header><h1>◈ GOLD TRADING BOT PRO <span style="font-size:13px">V2</span></h1>
<p>Analyse visuelle de captures XAUUSD · Mobile & PC</p></header><main>
<section class="card"><h2>Importer une capture du graphique</h2>
<p class="muted">Formats PNG, JPG ou WEBP · Maximum {{max_mb}} Mo. Utilise une seule fenêtre de graphique, nette et sans menus superposés.</p>
<form method="post" action="/analyze" enctype="multipart/form-data">
<input type="file" name="chart" accept=".png,.jpg,.jpeg,.webp" required>
<button type="submit">LANCER L'ANALYSE VISUELLE</button></form></section>
{% if error %}<section class="card"><h2>Erreur</h2><p class="error">{{error}}</p></section>{% endif %}
{% if result %}
<section class="card"><h2>Résultat de l'analyse</h2>
<p class="pill">{{result.decision}}</p>
<div class="statgrid" style="margin-top:14px">
<div class="stat">Biais visuel<b>{{result.visual_bias}}</b></div>
<div class="stat">Bougies repérées<b>{{result.detected_candles}}</b></div>
<div class="stat">Haussières récentes<b>{{result.recent_bullish_bodies}}</b></div>
<div class="stat">Baissières récentes<b>{{result.recent_bearish_bodies}}</b></div>
</div>
<p class="muted">Confiance : {{result.confidence}} · Image : {{result.image_size}}</p>
{% if image_url %}<img class="preview" src="{{image_url}}" alt="Capture analysée">{% endif %}
<h2 style="margin-top:18px">Modules de stratégie</h2>
<table><tr><th>Module</th><th>État</th><th>Observation</th></tr>
{% for s in strategies %}<tr><td>{{s.name}}</td><td>{{s.status}}</td><td>{{s.note}}</td></tr>{% endfor %}</table>
<h2 style="margin-top:18px">Lecture OCR facultative</h2><p class="muted">{{result.ocr.message}}</p>
{% if result.ocr.text %}<pre>{{result.ocr.text}}</pre>{% endif %}
<h2 style="margin-top:18px">Limites de l'analyse</h2><ul>{% for item in result.limitations %}<li class="muted">{{item}}</li>{% endfor %}</ul>
<details><summary>Détails techniques des bougies détectées</summary><pre>{{result.candle_samples|tojson(indent=2)}}</pre></details>
</section>{% endif %}
<section class="card"><p class="warning"><b>Important :</b> cette version analyse uniquement les pixels d'une capture. Un biais visuel n'est pas un signal de trading confirmé. Elle ne lit pas les cotations en direct, ne fournit pas de prix d'entrée/SL/TP fiables et ne passe aucun ordre.</p></section>
</main><footer>GOLD TRADING BOT PRO V2 · Analyse éducative uniquement</footer></body></html>
"""

def render_page(**kwargs):
    return render_template_string(PAGE, max_mb=MAX_UPLOAD_MB, **kwargs)

@app.get("/")
def home():
    return render_page(error=None, result=None, strategies=[], image_url=None)

@app.post("/analyze")
def analyze_image():
    try:
        f = request.files.get("chart")
        if not f or not f.filename:
            raise ValueError("Sélectionne une capture avant de lancer l'analyse.")
        suffix = Path(f.filename).suffix.lower()
        if suffix not in {".png",".jpg",".jpeg",".webp"}:
            raise ValueError("Format non accepté. Utilise PNG, JPG ou WEBP.")
        filename = f"chart_{int(time.time())}_{abs(hash(f.filename))%99999}{suffix}"
        path = UPLOAD_DIR / filename
        f.save(path)
        image = load_image(path)
        result = analyze_chart_image(image)
        strategies = build_strategy_notes(result)
        record = {"timestamp":time.time(),"filename":filename,"analysis":result}
        (HISTORY_DIR / f"analysis_{int(time.time())}.json").write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
        return render_page(error=None,result=result,strategies=strategies,image_url=url_for("uploaded_file",filename=filename))
    except Exception as exc:
        return render_page(error=str(exc),result=None,strategies=[],image_url=None)

@app.get("/uploads/<filename>")
def uploaded_file(filename):
    from flask import send_from_directory
    return send_from_directory(UPLOAD_DIR, filename)

@app.errorhandler(413)
def too_large(_):
    return render_page(error=f"Image trop volumineuse (maximum {MAX_UPLOAD_MB} Mo).",result=None,strategies=[],image_url=None)

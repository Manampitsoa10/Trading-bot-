from strategies import smc_ict, crt, rtm, qml, bbma

def build_strategy_notes(observation):
    modules = [smc_ict, crt, rtm, qml, bbma]
    return [m.analyze_visual(observation) for m in modules]

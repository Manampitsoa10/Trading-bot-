from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
HISTORY_DIR = BASE_DIR / "history"
for folder in (UPLOAD_DIR, HISTORY_DIR):
    folder.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_MB = 10

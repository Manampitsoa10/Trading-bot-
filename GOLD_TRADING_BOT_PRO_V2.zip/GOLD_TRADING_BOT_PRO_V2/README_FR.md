# GOLD TRADING BOT PRO V2 — analyse de captures uniquement

## Ce que fait cette version
- Téléversement d'une capture PNG/JPG/WEBP.
- Vérification et préparation de l'image.
- Repérage visuel indicatif des corps de bougies colorés.
- Estimation prudente de la direction visuelle récente lorsque suffisamment de bougies sont détectées.
- Tableau de bord mobile et historique JSON des analyses.
- Les modules SMC/ICT, CRT, RTM, QML et BBMA fournissent des observations heuristiques simples, pas des signaux institutionnels certifiés.

## Limites importantes
Une capture d'écran seule ne fournit pas les données OHLC exactes ni l'échelle numérique du graphique. Les couleurs, le thème, les indicateurs, les panneaux et le zoom changent selon TradingView/MT5.
Cette version ne prétend donc pas lire exactement les prix, identifier avec certitude un Order Block/FVG/liquidité, ni garantir des entrées, SL ou TP. Si la détection est insuffisante, le résultat reste WAIT / ANALYSE INSUFFISANTE.
Pas de données live, pas de connexion broker, pas d'ordre automatique.

## Installation Pydroid 3
1. Décompresse le ZIP dans un dossier.
2. Ouvre Pydroid 3 > Pip et installe `flask`, `pillow`, `numpy`.
3. OpenCV et pytesseract sont facultatifs ; si leur installation échoue, l'application fonctionne sans eux.
4. Ouvre `main.py` dans Pydroid 3 puis Run.
5. Dans Chrome, ouvre `http://127.0.0.1:5000`.
6. Laisse Pydroid ouvert pendant l'utilisation.

Commande possible dans le terminal :
`pip install flask pillow numpy`

## Installation PC
`python -m venv .venv`
Windows : `.venv\\Scripts\\activate`
Linux/macOS : `source .venv/bin/activate`
`pip install -r requirements.txt`
`python main.py`
Puis ouvrir `http://127.0.0.1:5000`.

## Conseils pour les captures
- Capture nette, sans flou, avec les bougies assez grandes.
- Afficher le graphique principal sans menus qui le recouvrent.
- Garder l'axe des prix visible si tu souhaites une future lecture OCR.
- Éviter les captures contenant plusieurs graphiques.
- Tester d'abord avec un compte démo et vérifier toute observation manuellement.

## OCR
`pytesseract` seul ne suffit pas : il faut aussi installer le moteur Tesseract natif. Sur Android/Pydroid, cette installation peut être compliquée. L'OCR est donc facultatif et son absence n'empêche pas l'analyse visuelle.

def analyze_visual(observation):
    return {"name":"RTM", "status":"À vérifier manuellement",
            "note":"Les zones de décision et la structure doivent être confirmées sur le graphique."}

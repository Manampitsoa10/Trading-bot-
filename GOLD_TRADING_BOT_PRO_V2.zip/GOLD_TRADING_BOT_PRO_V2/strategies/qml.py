def analyze_visual(observation):
    return {"name":"QML", "status":"À vérifier manuellement",
            "note":"Les points de structure nécessaires à un QML fiable ne sont pas extraits automatiquement ici."}

def analyze_visual(observation):
    return {"name":"SMC / ICT", "status":"À vérifier manuellement",
            "note":"Une capture seule ne permet pas de confirmer précisément BOS, CHoCH, FVG, Order Block ou sweep."}

def analyze_visual(observation):
    return {"name":"CRT", "status":"À vérifier manuellement",
            "note":"La range de référence et les niveaux de session doivent être définis pour valider CRT."}

def analyze_visual(observation):
    return {"name":"BBMA", "status":"À vérifier manuellement",
            "note":"Les bandes et moyennes doivent être identifiées ; leur présence/couleur varie selon le modèle du graphique."}

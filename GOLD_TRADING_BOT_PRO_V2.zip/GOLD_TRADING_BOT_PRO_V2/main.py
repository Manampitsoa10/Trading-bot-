from dashboard.dashboard import app

if __name__ == "__main__":
    print("GOLD TRADING BOT PRO V2")
    print("Serveur local : http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)

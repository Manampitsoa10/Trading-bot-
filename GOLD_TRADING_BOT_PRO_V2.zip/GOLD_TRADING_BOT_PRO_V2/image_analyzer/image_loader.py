from PIL import Image, ImageOps
from pathlib import Path
ALLOWED = {".png", ".jpg", ".jpeg", ".webp"}

def load_image(path):
    path = Path(path)
    if path.suffix.lower() not in ALLOWED:
        raise ValueError("Format accepté : PNG, JPG ou WEBP.")
    image = Image.open(path)
    image = ImageOps.exif_transpose(image).convert("RGB")
    if image.width < 240 or image.height < 160:
        raise ValueError("Image trop petite : utilise une capture plus nette.")
    return image

def read_price_text(image):
    try:
        import pytesseract
        text = pytesseract.image_to_string(image, config="--psm 11")
        if not text.strip():
            return {"available": True, "text": "", "message": "Aucun texte exploitable détecté."}
        return {"available": True, "text": text.strip()[:1500],
                "message": "OCR indicatif : vérifie chaque valeur manuellement."}
    except Exception as exc:
        return {"available": False, "text": "",
                "message": "OCR désactivé. Tesseract natif n'est pas installé ou accessible. L'analyse visuelle continue."}

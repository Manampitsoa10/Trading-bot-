from .candle_detector import detect_candles
from .price_reader import read_price_text

def analyze_chart_image(image):
    detected = detect_candles(image)
    candles = detected["candles"]
    recent = candles[-12:]
    bull = sum(c["visual_color"]=="bullish" for c in recent)
    bear = sum(c["visual_color"]=="bearish" for c in recent)
    if len(recent) < 5:
        bias = "INCONNU"
        confidence = "FAIBLE"
        decision = "WAIT — ANALYSE INSUFFISANTE"
    elif bull >= bear + 3:
        bias, confidence, decision = "HAUSSIER VISUEL", "FAIBLE À MODÉRÉE", "BUY BIAS À CONFIRMER"
    elif bear >= bull + 3:
        bias, confidence, decision = "BAISSIER VISUEL", "FAIBLE À MODÉRÉE", "SELL BIAS À CONFIRMER"
    else:
        bias, confidence, decision = "NEUTRE / MIXTE", "FAIBLE", "WAIT"
    return {
        "image_size": f"{image.width} x {image.height}",
        "detected_candles": detected["count"],
        "recent_candles_examined": len(recent),
        "recent_bullish_bodies": bull,
        "recent_bearish_bodies": bear,
        "visual_bias": bias,
        "confidence": confidence,
        "decision": decision,
        "ocr": read_price_text(image),
        "candle_samples": recent,
        "limitations": [
            "La détection peut confondre bougies, indicateurs et dessins.",
            "Les OHLC exacts et les prix ne sont pas reconstruits.",
            "SMC/ICT, CRT, RTM, QML et BBMA ne peuvent pas être validés avec certitude à partir des seuls pixels.",
            "Aucun ordre, stop-loss ou take-profit n'est généré."
        ],
        "next_step": "Utilise une capture nette du graphique principal, avec les bougies bien visibles."
    }

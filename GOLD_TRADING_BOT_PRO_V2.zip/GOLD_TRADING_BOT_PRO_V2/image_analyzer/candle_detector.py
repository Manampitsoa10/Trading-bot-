import numpy as np

def _runs(indices, max_gap=2):
    if not indices:
        return []
    groups, start, prev = [], indices[0], indices[0]
    for x in indices[1:]:
        if x - prev > max_gap + 1:
            groups.append((start, prev))
            start = x
        prev = x
    groups.append((start, prev))
    return groups

def detect_candles(image):
    """
    Heuristique de repérage de corps colorés sur un graphique sombre ou clair.
    Ne reconstruit PAS les OHLC et peut confondre bougies, indicateurs et dessins.
    """
    arr = np.asarray(image.convert("RGB"), dtype=np.int16)
    h, w, _ = arr.shape
    # Exclure bandes haut/bas où se trouvent souvent les barres d'outils.
    y0, y1 = int(h * 0.10), int(h * 0.90)
    crop = arr[y0:y1]
    r, g, b = crop[:,:,0], crop[:,:,1], crop[:,:,2]
    green = (g > r * 1.12) & (g > b * 1.04) & (g-r > 22)
    red = (r > g * 1.18) & (r > b * 1.12) & (r-g > 22)
    colored = green | red
    col_counts = colored.sum(axis=0)
    threshold = max(3, int((y1-y0) * 0.006))
    xs = [int(x) for x, n in enumerate(col_counts) if n >= threshold]
    groups = _runs(xs, max_gap=2)
    candles = []
    for left, right in groups:
        if right-left+1 > max(22, int(w*0.035)):
            continue
        region = colored[:, left:right+1]
        ys, xloc = np.where(region)
        if len(ys) < 4:
            continue
        gy = int(green[:,left:right+1].sum())
        ry = int(red[:,left:right+1].sum())
        color = "bullish" if gy > ry*1.25 else "bearish" if ry > gy*1.25 else "unclear"
        top = int(ys.min()+y0)
        bottom = int(ys.max()+y0)
        if bottom-top < 3:
            continue
        candles.append({
            "x": int((left+right)//2), "top_px": top, "bottom_px": bottom,
            "width_px": int(right-left+1), "height_px": int(bottom-top+1),
            "visual_color": color
        })
    return {
        "candles": candles,
        "count": len(candles),
        "green_count": sum(c["visual_color"]=="bullish" for c in candles),
        "red_count": sum(c["visual_color"]=="bearish" for c in candles),
        "method": "Détection heuristique des colonnes colorées"
    }
